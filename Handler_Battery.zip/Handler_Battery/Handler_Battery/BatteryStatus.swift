//
//  BatteryStatus.swift
//  Handler_Battery
//
//  Created by Raso Salvatore on 09/01/2019.
//  Copyright © 2019 Raso Salvatore. All rights reserved.
//

import Foundation
import UIKit

enum BatteryZoneType {
    case high
    case medium
    case low
    case unknown
}

class BatteryStatus {
    
    static let shared = BatteryStatus()
    
    private var currentStatus : BatteryZoneType = .unknown
    
    var batteryLevel: Float {
        return UIDevice.current.batteryLevel
    }
    
    private var batteryState: UIDevice.BatteryState {
        return UIDevice.current.batteryState
    }
    
    private var currentDevice = UIDevice.current
    
    var batteryManager = BatteryManager()
    
    // Singleton initializer
    private init() {
        currentDevice.isBatteryMonitoringEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(batteryLevelDidChange), name: UIDevice.batteryLevelDidChangeNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(batteryStateDidChange), name: UIDevice.batteryStateDidChangeNotification, object: nil)
    }
    
    
    // Methods to control battery Level
    @objc func batteryLevelDidChange(_ notification: Notification) {
        let batteryZone = self.checkBatteryLevel(batteryLevel: self.batteryLevel)
        
        if batteryZone != self.currentStatus {
            self.setNewBatteryZone(newState: batteryZone)
        } else {
            print("The battery is in the same zone")
        }
        print(batteryLevel)
    }
    
    private func checkBatteryLevel(batteryLevel: Float) -> BatteryZoneType {
        
        switch batteryLevel {
        case ..<0.4:
            if batteryLevel<0.2 {
                return .low
            } else {
                return .medium
            }
        default:
            return .high
        }
    }
    
    private func setNewBatteryZone(newState: BatteryZoneType) {
        switch newState {
        case .low:
            self.currentStatus = .low
            self.batteryManager.batteryLow()
            print("battery low")
            
        case .medium:
            self.currentStatus = .medium
            self.batteryManager.batteryMedium()
            print("battery medium")
            
        default:
            self.currentStatus = .high
            self.batteryManager.batteryHigh()
            print("battery high")
        }
    }
    
    
    // Method to control battery State
    @objc func batteryStateDidChange(_ notification: Notification) {

        switch self.batteryState {
        case .unplugged, .unknown:
            self.batteryManager.phoneUnplugged()
        case .charging, .full:
            self.batteryManager.phoneOnCharging()
        }
    }
    
}
