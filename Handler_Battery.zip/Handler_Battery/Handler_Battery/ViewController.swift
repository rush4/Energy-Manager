//
//  ViewController.swift
//  Handler_Battery
//
//  Created by Raso Salvatore on 09/01/2019.
//  Copyright © 2019 Raso Salvatore. All rights reserved.
//

import UIKit


class ViewController: UIViewController, BatteryManagerDelegate {
    
    @IBOutlet weak var batteryLevelLabel: UILabel!

    @IBOutlet weak var batteryZoneLabel: UILabel!
    
    @IBOutlet weak var batteryStateLabel: UILabel!
    
    var batteryManager = BatteryManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        _ = BatteryStatus.shared
        self.batteryManager.delegate = self
        BatteryStatus.shared.batteryManager = self.batteryManager
        #if DEBUG
        print("Ho già mangiato")
        #endif
    }

    @IBAction func retrieveBatteryButton(_ sender: Any) {
        
        self.batteryLevelLabel.text = String(BatteryStatus.shared.batteryLevel)
    }
    
    func printBatteryLevel(message: String, color: UIColor) {
        DispatchQueue.main.async {

        print("aggiorna label")
        self.batteryZoneLabel.text = message
        self.batteryZoneLabel.textColor = color
        }
    }
    
    func printBatteryState(message: String){
        DispatchQueue.main.async {
            self.batteryStateLabel.text = message
        }
    }
}

