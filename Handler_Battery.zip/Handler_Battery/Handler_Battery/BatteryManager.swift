//
//  BatteryManager.swift
//  Handler_Battery
//
//  Created by Raso Salvatore on 10/01/2019.
//  Copyright © 2019 Raso Salvatore. All rights reserved.
//

import Foundation
import UIKit

protocol BatteryManagerDelegate {
    func printBatteryLevel(message: String, color: UIColor)
    func printBatteryState(message: String)
}

class BatteryManager {
    
    static let shared = BatteryManager()
    
    var delegate : BatteryManagerDelegate?
    
    func batteryLow() {
        self.delegate?.printBatteryLevel(message: "Low Level", color: UIColor.red)
    }
    
    func batteryMedium() {
        delegate?.printBatteryLevel(message: "Medium Level", color: UIColor.blue)
    }
    
    func batteryHigh() {
            self.delegate?.printBatteryLevel(message: "High Level", color: UIColor.green)
    }
    
    func phoneUnplugged() {
        self.delegate?.printBatteryState(message: "Unplugged")
        print("Unplugged")
    }
    
    func phoneOnCharging() {
        self.delegate?.printBatteryState(message: "OnCharging")
        print("OnCharging")
    }
}
